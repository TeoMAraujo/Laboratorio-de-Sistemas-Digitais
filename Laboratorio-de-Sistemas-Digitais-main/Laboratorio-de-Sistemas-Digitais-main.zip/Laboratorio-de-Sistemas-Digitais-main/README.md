## Disciplina:
Laboratorio de Sistemas Digitais - ELT029 - UFMG 2025/2
### Placa:
- DE10 - 10M50DAF484C7G
- Software Usado: QUARTUS PRIME


