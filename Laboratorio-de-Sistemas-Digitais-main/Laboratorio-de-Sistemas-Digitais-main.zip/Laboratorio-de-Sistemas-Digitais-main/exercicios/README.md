### Links:
5. [https://www.edaplayground.com/x/P2E_](https://www.edaplayground.com/x/P2E_)
6. https://edaplayground.com/x/wfqp
7. https://edaplayground.com/x/b9Pv
8. https://edaplayground.com/x/gQrd
9. https://edaplayground.com/x/WrnP +  https://drive.google.com/file/d/10OFwpdj8iYfp5Uheu-YqGZtuuQSuB2MI/view?usp=drive_link
10. https://www.edaplayground.com/x/qXUz
