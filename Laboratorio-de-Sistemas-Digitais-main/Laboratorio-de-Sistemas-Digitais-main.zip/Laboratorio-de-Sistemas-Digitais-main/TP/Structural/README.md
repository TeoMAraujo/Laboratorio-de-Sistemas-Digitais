<img width="1914" height="1398" alt="image" src="https://github.com/user-attachments/assets/dec3fd1e-4dc7-4635-82c7-b4fd80b9d0fe" />
