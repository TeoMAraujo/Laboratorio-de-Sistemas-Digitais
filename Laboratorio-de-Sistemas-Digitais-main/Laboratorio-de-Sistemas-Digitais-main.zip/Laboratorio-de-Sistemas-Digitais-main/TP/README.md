<img width="1280" height="808" alt="image" src="https://github.com/user-attachments/assets/2e8ea017-0edc-4c47-9c12-099aa6997950" />

